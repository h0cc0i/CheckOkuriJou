﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoCheckAndSendReport
{
    public class _info
    {
        string _Juchuu;
        string _Chuumon;
        string _Zumen;
        string _Kazu;
        string _Tanka;
        string _Kingaku;
        string _JuchuuNouki;
        string _Bikou;

        public string Juchuu
        {
            get { return _Juchuu; }
            set { _Juchuu = value; }
        }

        public string Chuumon
        {
            get { return _Chuumon; }
            set { _Chuumon = value; }
        }
        public string Zumen
        {
            get { return _Zumen; }
            set { _Zumen = value; }
        }
        public string Kazu
        {
            get { return _Kazu; }
            set { _Kazu = value; }
        }
        public string Tanka
        {
            get { return _Tanka; }
            set { _Tanka = value; }
        }
        public string Kingaku
        {
            get { return _Kingaku; }
            set { _Kingaku = value; }
        }

        public string JuchuNoki
        {
            get { return _JuchuuNouki; }
            set { _JuchuuNouki = value; }
        }

        public string Bikou
        {
            get { return _Bikou; }
            set { _Bikou = value; }
        }
    }
}
